rm -f phantom.zip
zip -r phantom.zip . --exclude=*.DS_Store* --exclude=*.git* --exclude=*node_modules* --exclude=*.idea* --exclude=*.c9*